// module.exports = {
//     "dynamoose": require("dynamoose"),
//     "parse-error": require("parse-error"),
//     "uuidv4": require("uuidv4"),
// };
